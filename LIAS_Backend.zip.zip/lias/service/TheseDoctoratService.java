package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.TheseDoctorat;
import ma.fsbenmsik.lias.repository.TheseDoctoratRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TheseDoctoratService {

    private final TheseDoctoratRepository repository;

    public TheseDoctoratService(TheseDoctoratRepository repository) {
        this.repository = repository;
    }

    public List<TheseDoctorat> getAll() {
        return repository.findAll();
    }

    public TheseDoctorat save(TheseDoctorat theseDoctorat) {
        return repository.save(theseDoctorat);
    }

    public TheseDoctorat update(Long id, TheseDoctorat theseDoctorat) {
        theseDoctorat.setId(id);
        return repository.save(theseDoctorat);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
