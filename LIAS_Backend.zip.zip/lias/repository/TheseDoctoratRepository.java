package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.TheseDoctorat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TheseDoctoratRepository extends JpaRepository<TheseDoctorat, Long> {
}
