package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "theses_doctorat")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TheseDoctorat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String doctorant;
    private String sujet;
    private String directeur;
    private Integer anneeInscription;
    private String statut;
}
