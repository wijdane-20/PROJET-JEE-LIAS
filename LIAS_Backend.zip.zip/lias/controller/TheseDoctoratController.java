package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.TheseDoctorat;
import ma.fsbenmsik.lias.service.TheseDoctoratService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/theses")
@CrossOrigin(origins = "http://localhost:4200")
public class TheseDoctoratController {

    private final TheseDoctoratService service;

    public TheseDoctoratController(TheseDoctoratService service) {
        this.service = service;
    }

    @GetMapping
    public List<TheseDoctorat> getAll() {
        return service.getAll();
    }

    @PostMapping
    public TheseDoctorat create(@RequestBody TheseDoctorat theseDoctorat) {
        return service.save(theseDoctorat);
    }

    @PutMapping("/{id}")
    public TheseDoctorat update(@PathVariable Long id, @RequestBody TheseDoctorat theseDoctorat) {
        return service.update(id, theseDoctorat);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
