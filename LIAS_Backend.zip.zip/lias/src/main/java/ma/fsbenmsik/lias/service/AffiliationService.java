package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.Affiliation;
import ma.fsbenmsik.lias.repository.AffiliationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AffiliationService {

    private final AffiliationRepository repository;

    public AffiliationService(AffiliationRepository repository) {
        this.repository = repository;
    }

    public List<Affiliation> getAll() {
        return repository.findAll();
    }

    public List<Affiliation> getByMembre(Long membreId) {
        return repository.findByMembreId(membreId);
    }

    public Affiliation save(Affiliation affiliation) {
        return repository.save(affiliation);
    }

    public Affiliation update(Long id, Affiliation affiliation) {
        affiliation.setId(id);
        return repository.save(affiliation);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}