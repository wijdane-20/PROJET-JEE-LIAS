package ma.fsbenmsik.lias.controller;

import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/public")
@CrossOrigin(origins = "*")
public class PublicController {

    @GetMapping("/presentation")
    public Map<String, Object> presentation() {
        return Map.of(
                "nom", "LIAS",
                "nomComplet", "Laboratoire d'Informatique et Applications Scientifiques",
                "etablissement", "Faculté des Sciences Ben M'Sik – Casablanca",
                "mission", "Recherche, innovation, collaboration scientifique et valorisation des activités du laboratoire."
        );
    }
}
