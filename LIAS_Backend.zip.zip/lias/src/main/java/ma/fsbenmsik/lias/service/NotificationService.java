package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.Notification;
import ma.fsbenmsik.lias.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class NotificationService {
    private final NotificationRepository repository;

    public NotificationService(NotificationRepository repository) {
        this.repository = repository;
    }

    public List<Notification> getAll() {
        return repository.findAll();
    }

    public Notification save(Notification value) {
        return repository.save(value);
    }

    public Notification update(Long id, Notification value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
