package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.RoleHistorique;
import ma.fsbenmsik.lias.service.RoleHistoriqueService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/roles-historiques")
@CrossOrigin(origins = "*")
public class RoleHistoriqueController {
    private final RoleHistoriqueService service;
    private final AuditService audit;

    public RoleHistoriqueController(RoleHistoriqueService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<RoleHistorique> getAll() { return service.getAll(); }

    @PostMapping
    public RoleHistorique create(@RequestBody RoleHistorique value) {

        RoleHistorique saved = service.save(value);
        audit.log("CREATE", "RoleHistorique", saved.getId(), "utilisateur", "Création RoleHistorique");
        return saved;
    }

    @PutMapping("/{id}")
    public RoleHistorique update(@PathVariable Long id, @RequestBody RoleHistorique value) {
        RoleHistorique saved = service.update(id, value);
        audit.log("UPDATE", "RoleHistorique", id, "utilisateur", "Modification RoleHistorique");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "RoleHistorique", id, "utilisateur", "Suppression RoleHistorique");
    }
}
