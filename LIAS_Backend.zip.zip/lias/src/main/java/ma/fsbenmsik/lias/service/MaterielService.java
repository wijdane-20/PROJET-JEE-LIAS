package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.Materiel;
import ma.fsbenmsik.lias.repository.MaterielRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MaterielService {
    private final MaterielRepository repository;

    public MaterielService(MaterielRepository repository) {
        this.repository = repository;
    }

    public List<Materiel> getAll() {
        return repository.findAll();
    }

    public Materiel save(Materiel value) {
        return repository.save(value);
    }

    public Materiel update(Long id, Materiel value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
