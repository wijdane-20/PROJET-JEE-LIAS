package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Publication;
import ma.fsbenmsik.lias.service.PublicationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/publications")
@CrossOrigin(origins = "*")
public class PublicationController {

    private final PublicationService publicationService;

    public PublicationController(PublicationService publicationService) {
        this.publicationService = publicationService;
    }

    @GetMapping
    public List<Publication> getAllPublications() {
        return publicationService.getAllPublications();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Publication> getPublicationById(
            @PathVariable Long id) {

        return publicationService
                .getPublicationById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Publication createPublication(
            @RequestBody Publication publication) {

        return publicationService.savePublication(publication);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Publication> updatePublication(
            @PathVariable Long id,
            @RequestBody Publication publication) {

        return publicationService
                .getPublicationById(id)
                .map(existing -> {
                    publication.setId(id);

                    Publication updatedPublication =
                            publicationService.savePublication(publication);

                    return ResponseEntity.ok(updatedPublication);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePublication(
            @PathVariable Long id) {

        if (publicationService.getPublicationById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        publicationService.deletePublication(id);

        return ResponseEntity.noContent().build();
    }
}