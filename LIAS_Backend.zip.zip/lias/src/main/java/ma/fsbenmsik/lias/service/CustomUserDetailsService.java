package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.Mandat;
import ma.fsbenmsik.lias.entity.Membre;
import ma.fsbenmsik.lias.entity.Utilisateur;
import ma.fsbenmsik.lias.repository.MandatRepository;
import ma.fsbenmsik.lias.repository.MembreRepository;
import ma.fsbenmsik.lias.repository.UtilisateurRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UtilisateurRepository utilisateurRepository;
    private final MembreRepository membreRepository;
    private final MandatRepository mandatRepository;

    public CustomUserDetailsService(
            UtilisateurRepository utilisateurRepository,
            MembreRepository membreRepository,
            MandatRepository mandatRepository
    ) {
        this.utilisateurRepository = utilisateurRepository;
        this.membreRepository = membreRepository;
        this.mandatRepository = mandatRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Utilisateur utilisateur = utilisateurRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Utilisateur introuvable"));

        List<SimpleGrantedAuthority> authorities = new ArrayList<>();

        // Rôle technique du compte
        authorities.add(
                new SimpleGrantedAuthority("ROLE_" + utilisateur.getRole().name())
        );

        // Recherche de la fiche membre associée au même email
        Optional<Membre> membreOptional =
                membreRepository.findByEmailIgnoreCase(utilisateur.getEmail());

        if (membreOptional.isPresent()) {

            Membre membre = membreOptional.get();

            // Statut du membre : PERMANENT, ASSOCIE, DOCTORANT, RETRAITE, ANCIEN...
            if (membre.getStatut() != null) {
                authorities.add(
                        new SimpleGrantedAuthority(
                                "STATUT_" + membre.getStatut().toString()
                        )
                );
            }

            // Mandat actif : DIRECTEUR, VICE_DIRECTEUR, CHEF_EQUIPE...
            Optional<Mandat> mandatActif =
                    mandatRepository.findFirstByMembreIdAndActifTrue(membre.getId());

            if (mandatActif.isPresent() && mandatActif.get().getRole() != null) {
                authorities.add(
                        new SimpleGrantedAuthority(
                                "MANDAT_" + mandatActif.get().getRole()
                        )
                );
            }
        }

        return User.builder()
                .username(utilisateur.getEmail())
                .password(utilisateur.getPassword())
                .authorities(authorities)
                .disabled(!utilisateur.isActif())
                .build();
    }
}