package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.service.RapportService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/rapport")
@CrossOrigin(origins = "*")
public class RapportController {

    private final RapportService rapportService;

    public RapportController(RapportService rapportService) {
        this.rapportService = rapportService;
    }

    @GetMapping("/statistiques")
    public Map<String, Long> getStatistiques() {
        return rapportService.getStatistiques();
    }
}