package ma.fsbenmsik.lias.config;

import ma.fsbenmsik.lias.entity.TheseDoctorat;
import ma.fsbenmsik.lias.repository.TheseDoctoratRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TheseDoctoratInitializer {

    @Bean
    CommandLineRunner initTheses(TheseDoctoratRepository repository) {

        return args -> {

            if (repository.count() == 0) {

                TheseDoctorat these1 = TheseDoctorat.builder()
                        .doctorant("Imane El Fassi")
                        .sujet("Intelligence Artificielle pour le Diagnostic Médical")
                        .directeur("Pr. Nabil Chraibi")
                        .anneeInscription(2021)
                        .statut("SOUTENUE")
                        .build();

                TheseDoctorat these2 = TheseDoctorat.builder()
                        .doctorant("Omar Berrada")
                        .sujet("Détection d'Anomalies dans les Réseaux IoT")
                        .directeur("Pr. Salma Ouazzani")
                        .anneeInscription(2022)
                        .statut("EN_COURS")
                        .build();

                TheseDoctorat these3 = TheseDoctorat.builder()
                        .doctorant("Nadia Amrani")
                        .sujet("Vision par Ordinateur pour les Systèmes Intelligents")
                        .directeur("Pr. Yassine Lahlou")
                        .anneeInscription(2023)
                        .statut("EN_COURS")
                        .build();

                TheseDoctorat these4 = TheseDoctorat.builder()
                        .doctorant("Hamza Idrissi")
                        .sujet("Cybersécurité des Systèmes Industriels Connectés")
                        .directeur("Pr. Meryem Benjelloun")
                        .anneeInscription(2024)
                        .statut("EN_COURS")
                        .build();

                TheseDoctorat these5 = TheseDoctorat.builder()
                        .doctorant("Sara El Mansouri")
                        .sujet("Apprentissage Automatique pour l'Optimisation Énergétique")
                        .directeur("Pr. Adil Tazi")
                        .anneeInscription(2020)
                        .statut("SUSPENDUE")
                        .build();

                repository.save(these1);
                repository.save(these2);
                repository.save(these3);
                repository.save(these4);
                repository.save(these5);

                System.out.println("5 thèses de doctorat initialisées avec succès.");
            }
        };
    }
}