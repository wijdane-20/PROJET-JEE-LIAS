package ma.fsbenmsik.lias.entity;

public enum Role {
    ADMIN,
    RESPONSABLE,
    MEMBRE
}