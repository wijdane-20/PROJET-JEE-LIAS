package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.AttributionMateriel;
import ma.fsbenmsik.lias.repository.AttributionMaterielRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AttributionMaterielService {
    private final AttributionMaterielRepository repository;

    public AttributionMaterielService(AttributionMaterielRepository repository) {
        this.repository = repository;
    }

    public List<AttributionMateriel> getAll() {
        return repository.findAll();
    }

    public AttributionMateriel save(AttributionMateriel value) {
        return repository.save(value);
    }

    public AttributionMateriel update(Long id, AttributionMateriel value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
