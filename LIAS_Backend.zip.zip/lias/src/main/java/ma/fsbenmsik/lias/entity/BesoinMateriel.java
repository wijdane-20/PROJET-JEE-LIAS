package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "besoins_materiel")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BesoinMateriel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long membreId;
    private String materielDemande;
    private Integer quantite;
    @Column(length = 3000)
    private String justification;
    private String statut;
    private LocalDateTime dateDemande;
}
