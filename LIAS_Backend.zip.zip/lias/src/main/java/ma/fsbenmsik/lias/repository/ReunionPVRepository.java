package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.ReunionPV;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReunionPVRepository extends JpaRepository<ReunionPV, Long> {
}
