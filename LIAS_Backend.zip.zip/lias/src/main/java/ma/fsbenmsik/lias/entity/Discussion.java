package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "discussions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Discussion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String auteurEmail;
    private String equipe;
    private Long evenementId;
    @Column(length = 4000)
    private String contenu;
    private LocalDateTime dateCreation;
}
