package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.ReunionPV;
import ma.fsbenmsik.lias.service.ReunionPVService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/reunions-pv")
@CrossOrigin(origins = "*")
public class ReunionPVController {
    private final ReunionPVService service;
    private final AuditService audit;

    public ReunionPVController(ReunionPVService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<ReunionPV> getAll() { return service.getAll(); }

    @PostMapping
    public ReunionPV create(@RequestBody ReunionPV value) {

        ReunionPV saved = service.save(value);
        audit.log("CREATE", "ReunionPV", saved.getId(), "utilisateur", "Création ReunionPV");
        return saved;
    }

    @PutMapping("/{id}")
    public ReunionPV update(@PathVariable Long id, @RequestBody ReunionPV value) {
        ReunionPV saved = service.update(id, value);
        audit.log("UPDATE", "ReunionPV", id, "utilisateur", "Modification ReunionPV");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "ReunionPV", id, "utilisateur", "Suppression ReunionPV");
    }
}
