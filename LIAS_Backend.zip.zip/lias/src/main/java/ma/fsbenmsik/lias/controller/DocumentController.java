package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Document;
import ma.fsbenmsik.lias.service.DocumentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin(origins = "*")
public class DocumentController {

    private final DocumentService service;

    public DocumentController(DocumentService service) {
        this.service = service;
    }

    @GetMapping
    public List<Document> getAll() {
        return service.getAll();
    }

    @PostMapping
    public Document create(@RequestBody Document document) {
        return service.save(document);
    }

    @PutMapping("/{id}")
    public Document update(
            @PathVariable Long id,
            @RequestBody Document document) {

        return service.update(id, document);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}