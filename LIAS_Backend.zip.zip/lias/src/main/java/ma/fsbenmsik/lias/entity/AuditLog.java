package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String action;
    private String entite;
    private Long entiteId;
    private String utilisateur;
    @Column(length = 4000)
    private String details;
    private LocalDateTime dateAction;
}
