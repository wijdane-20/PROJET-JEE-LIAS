package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Convention;
import ma.fsbenmsik.lias.service.ConventionService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/conventions")
@CrossOrigin(origins = "*")
public class ConventionController {
    private final ConventionService service;
    private final AuditService audit;

    public ConventionController(ConventionService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<Convention> getAll() { return service.getAll(); }

    @PostMapping
    public Convention create(@RequestBody Convention value) {

        Convention saved = service.save(value);
        audit.log("CREATE", "Convention", saved.getId(), "utilisateur", "Création Convention");
        return saved;
    }

    @PutMapping("/{id}")
    public Convention update(@PathVariable Long id, @RequestBody Convention value) {
        Convention saved = service.update(id, value);
        audit.log("UPDATE", "Convention", id, "utilisateur", "Modification Convention");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "Convention", id, "utilisateur", "Suppression Convention");
    }
}
