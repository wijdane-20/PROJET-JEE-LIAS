package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.Membre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MembreRepository extends JpaRepository<Membre, Long> {

    Optional<Membre> findByEmailIgnoreCase(String email);
}