package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Notification;
import ma.fsbenmsik.lias.service.NotificationService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "*")
public class NotificationController {
    private final NotificationService service;
    private final AuditService audit;

    public NotificationController(NotificationService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<Notification> getAll() { return service.getAll(); }

    @PostMapping
    public Notification create(@RequestBody Notification value) {
        if (value.getDateCreation() == null) value.setDateCreation(LocalDateTime.now());
        Notification saved = service.save(value);
        audit.log("CREATE", "Notification", saved.getId(), "utilisateur", "Création Notification");
        return saved;
    }

    @PutMapping("/{id}")
    public Notification update(@PathVariable Long id, @RequestBody Notification value) {
        Notification saved = service.update(id, value);
        audit.log("UPDATE", "Notification", id, "utilisateur", "Modification Notification");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "Notification", id, "utilisateur", "Suppression Notification");
    }
}
