package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Membre;
import ma.fsbenmsik.lias.service.MembreService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/membres")
@CrossOrigin(origins = "*")
public class MembreController {

    private final MembreService membreService;

    public MembreController(MembreService membreService) {
        this.membreService = membreService;
    }

    @GetMapping
    public List<Membre> getAllMembres() {
        return membreService.getAllMembres();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Membre> getMembreById(
            @PathVariable Long id) {

        return membreService
                .getMembreById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Membre createMembre(
            @RequestBody Membre membre) {

        return membreService.saveMembre(membre);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Membre> updateMembre(
            @PathVariable Long id,
            @RequestBody Membre membre) {

        return membreService
                .getMembreById(id)
                .map(existing -> {
                    membre.setId(id);

                    Membre updatedMembre =
                            membreService.saveMembre(membre);

                    return ResponseEntity.ok(updatedMembre);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMembre(
            @PathVariable Long id) {

        if (membreService.getMembreById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        membreService.deleteMembre(id);

        return ResponseEntity.noContent().build();
    }
}