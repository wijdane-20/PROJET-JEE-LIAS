
package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Mandat;
import ma.fsbenmsik.lias.service.MandatService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mandats")
@CrossOrigin(origins = "*")
public class MandatController {

    private final MandatService service;

    public MandatController(MandatService service) {
        this.service = service;
    }

    @GetMapping
    public List<Mandat> getAll() {
        return service.getAll();
    }

    @GetMapping("/membre/{membreId}")
    public List<Mandat> getByMembre(
            @PathVariable Long membreId) {

        return service.getByMembre(membreId);
    }

    @PostMapping
    public Mandat create(
            @RequestBody Mandat mandat) {

        return service.save(mandat);
    }

    @PutMapping("/{id}")
    public Mandat update(
            @PathVariable Long id,
            @RequestBody Mandat mandat) {

        return service.update(id, mandat);
    }

    @DeleteMapping("/{id}")
    public void delete(
            @PathVariable Long id) {

        service.delete(id);
    }
}