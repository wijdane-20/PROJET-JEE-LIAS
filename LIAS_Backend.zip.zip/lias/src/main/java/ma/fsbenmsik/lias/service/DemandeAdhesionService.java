package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.DemandeAdhesion;
import ma.fsbenmsik.lias.repository.DemandeAdhesionRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DemandeAdhesionService {
    private final DemandeAdhesionRepository repository;

    public DemandeAdhesionService(DemandeAdhesionRepository repository) {
        this.repository = repository;
    }

    public List<DemandeAdhesion> getAll() {
        return repository.findAll();
    }

    public DemandeAdhesion save(DemandeAdhesion value) {
        return repository.save(value);
    }

    public DemandeAdhesion update(Long id, DemandeAdhesion value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
