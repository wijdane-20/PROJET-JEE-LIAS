package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.AuditLog;
import ma.fsbenmsik.lias.repository.AuditLogRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AuditLogService {
    private final AuditLogRepository repository;

    public AuditLogService(AuditLogRepository repository) {
        this.repository = repository;
    }

    public List<AuditLog> getAll() {
        return repository.findAll();
    }

    public AuditLog save(AuditLog value) {
        return repository.save(value);
    }

    public AuditLog update(Long id, AuditLog value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
