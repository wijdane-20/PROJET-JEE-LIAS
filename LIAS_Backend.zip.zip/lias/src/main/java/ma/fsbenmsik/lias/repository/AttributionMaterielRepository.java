package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.AttributionMateriel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AttributionMaterielRepository extends JpaRepository<AttributionMateriel, Long> {
}
