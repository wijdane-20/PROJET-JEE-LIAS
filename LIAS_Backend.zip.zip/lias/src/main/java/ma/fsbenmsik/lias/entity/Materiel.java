package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "materiels")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Materiel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nom;
    private String categorie;
    private Integer quantiteTotale;
    private Integer quantiteDisponible;
    private LocalDate dateArrivage;
    @Column(length = 2000)
    private String description;
}
