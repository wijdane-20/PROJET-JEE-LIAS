package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.repository.MembreRepository;
import ma.fsbenmsik.lias.repository.EquipeRepository;
import ma.fsbenmsik.lias.repository.PublicationRepository;
import ma.fsbenmsik.lias.repository.EvenementRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class RapportService {

    private final MembreRepository membreRepository;
    private final EquipeRepository equipeRepository;
    private final PublicationRepository publicationRepository;
    private final EvenementRepository evenementRepository;

    public RapportService(
            MembreRepository membreRepository,
            EquipeRepository equipeRepository,
            PublicationRepository publicationRepository,
            EvenementRepository evenementRepository) {

        this.membreRepository = membreRepository;
        this.equipeRepository = equipeRepository;
        this.publicationRepository = publicationRepository;
        this.evenementRepository = evenementRepository;
    }

    public Map<String, Long> getStatistiques() {

        Map<String, Long> statistiques = new HashMap<>();

        statistiques.put("membres", membreRepository.count());
        statistiques.put("equipes", equipeRepository.count());
        statistiques.put("publications", publicationRepository.count());
        statistiques.put("evenements", evenementRepository.count());

        return statistiques;
    }
}