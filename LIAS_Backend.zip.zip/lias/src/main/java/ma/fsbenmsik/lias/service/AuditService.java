package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.AuditLog;
import ma.fsbenmsik.lias.repository.AuditLogRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class AuditService {
    private final AuditLogRepository repository;

    public AuditService(AuditLogRepository repository) {
        this.repository = repository;
    }

    public void log(String action, String entite, Long entiteId, String utilisateur, String details) {
        repository.save(AuditLog.builder()
                .action(action)
                .entite(entite)
                .entiteId(entiteId)
                .utilisateur(utilisateur)
                .details(details)
                .dateAction(LocalDateTime.now())
                .build());
    }
}
