package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "publications")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Publication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titre;

    private String type;

    private Integer annee;

    private String auteurPrincipal;

    private String doi;

    private String lien;

    @Column(length = 2000)
    private String resume;

    private String equipe;
}