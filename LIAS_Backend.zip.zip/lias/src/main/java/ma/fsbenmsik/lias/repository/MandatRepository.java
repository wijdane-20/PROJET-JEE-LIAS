package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.Mandat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MandatRepository extends JpaRepository<Mandat, Long> {

    List<Mandat> findByMembreId(Long membreId);

    Optional<Mandat> findFirstByMembreIdAndActifTrue(Long membreId);
}