package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Materiel;
import ma.fsbenmsik.lias.service.MaterielService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/materiels")
@CrossOrigin(origins = "*")
public class MaterielController {
    private final MaterielService service;
    private final AuditService audit;

    public MaterielController(MaterielService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<Materiel> getAll() { return service.getAll(); }

    @PostMapping
    public Materiel create(@RequestBody Materiel value) {

        Materiel saved = service.save(value);
        audit.log("CREATE", "Materiel", saved.getId(), "utilisateur", "Création Materiel");
        return saved;
    }

    @PutMapping("/{id}")
    public Materiel update(@PathVariable Long id, @RequestBody Materiel value) {
        Materiel saved = service.update(id, value);
        audit.log("UPDATE", "Materiel", id, "utilisateur", "Modification Materiel");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "Materiel", id, "utilisateur", "Suppression Materiel");
    }
}
