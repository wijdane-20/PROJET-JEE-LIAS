package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "mandats")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Mandat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long membreId;

    private String role;

    private LocalDate dateDebut;

    private LocalDate dateFin;

    private boolean actif;
}
