package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.DemandeAdhesion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DemandeAdhesionRepository extends JpaRepository<DemandeAdhesion, Long> {
}
