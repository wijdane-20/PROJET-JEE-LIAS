package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Document;
import ma.fsbenmsik.lias.entity.Evenement;
import ma.fsbenmsik.lias.entity.Membre;
import ma.fsbenmsik.lias.entity.Publication;
import ma.fsbenmsik.lias.repository.DocumentRepository;
import ma.fsbenmsik.lias.repository.EvenementRepository;
import ma.fsbenmsik.lias.repository.MembreRepository;
import ma.fsbenmsik.lias.repository.PublicationRepository;
import org.springframework.web.bind.annotation.*;

import java.text.Normalizer;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/search")
@CrossOrigin(origins = "*")
public class SearchController {

    private final MembreRepository membres;
    private final DocumentRepository documents;
    private final EvenementRepository evenements;
    private final PublicationRepository publications;

    public SearchController(
            MembreRepository membres,
            DocumentRepository documents,
            EvenementRepository evenements,
            PublicationRepository publications) {

        this.membres = membres;
        this.documents = documents;
        this.evenements = evenements;
        this.publications = publications;
    }

    @GetMapping
    public Map<String, Object> search(@RequestParam(required = false) String q) {

        List<String> mots = prepareSearchTerms(q);

        if (mots.isEmpty()) {
            return Map.of(
                    "membres", List.of(),
                    "documents", List.of(),
                    "evenements", List.of(),
                    "publications", List.of()
            );
        }

        List<Membre> resultatMembres = membres.findAll().stream()
                .filter(v -> scoreMembre(v, mots) > 0)
                .sorted((a, b) -> Integer.compare(scoreMembre(b, mots), scoreMembre(a, mots)))
                .collect(Collectors.toList());

        List<Document> resultatDocuments = documents.findAll().stream()
                .filter(v -> scoreDocument(v, mots) > 0)
                .sorted((a, b) -> Integer.compare(scoreDocument(b, mots), scoreDocument(a, mots)))
                .collect(Collectors.toList());

        List<Evenement> resultatEvenements = evenements.findAll().stream()
                .filter(v -> scoreEvenement(v, mots) > 0)
                .sorted((a, b) -> Integer.compare(scoreEvenement(b, mots), scoreEvenement(a, mots)))
                .collect(Collectors.toList());

        List<Publication> resultatPublications = publications.findAll().stream()
                .filter(v -> scorePublication(v, mots) > 0)
                .sorted((a, b) -> Integer.compare(scorePublication(b, mots), scorePublication(a, mots)))
                .collect(Collectors.toList());

        return Map.of(
                "membres", resultatMembres,
                "documents", resultatDocuments,
                "evenements", resultatEvenements,
                "publications", resultatPublications
        );
    }

    private List<String> prepareSearchTerms(String query) {

        if (query == null || query.isBlank()) {
            return List.of();
        }

        String normalized = normalize(query);

        Set<String> terms = new LinkedHashSet<>();

        for (String mot : normalized.split("\\s+")) {
            if (mot.length() >= 2) {
                terms.add(mot);
            }
        }

        // Variantes utiles
        if (normalized.contains("intelligence artificielle")) {
            terms.add("intelligence");
            terms.add("artificielle");
            terms.add("deep");
            terms.add("learning");
        }

        if (terms.contains("ia")) {
            terms.add("intelligence");
            terms.add("artificielle");
        }

        if (normalized.contains("deep learning")) {
            terms.add("deep");
            terms.add("learning");
            terms.add("apprentissage");
            terms.add("profond");
        }

        if (normalized.contains("machine learning")) {
            terms.add("machine");
            terms.add("learning");
            terms.add("apprentissage");
        }

        if (normalized.contains("cybersecurite") || terms.contains("cyber")) {
            terms.add("cybersecurite");
            terms.add("securite");
            terms.add("reseaux");
        }

        if (normalized.contains("big data")) {
            terms.add("big");
            terms.add("data");
            terms.add("donnees");
        }

        return new ArrayList<>(terms);
    }

    private int scoreMembre(Membre v, List<String> mots) {

        String texte = join(
                v.getNom(),
                v.getPrenom(),
                v.getEmail(),
                v.getStatut(),
                v.getEtablissementOrigine(),
                v.getLaboratoireOrigine(),
                v.getBiographie(),
                v.getCentresInteret(),
                String.valueOf(v.getDateNaissance()),
                String.valueOf(v.getDateEmbauche()),
                String.valueOf(v.getDateAffiliation())
        );

        return calculateScore(texte, mots);
    }

    private int scoreDocument(Document v, List<String> mots) {

        String texte = join(
                v.getTitre(),
                v.getType(),
                v.getDescription(),
                String.valueOf(v.getDateAjout())
        );

        return calculateScore(texte, mots);
    }

    private int scoreEvenement(Evenement v, List<String> mots) {

        String texte = join(
                v.getTitre(),
                v.getType(),
                v.getLieu(),
                v.getOrganisateur(),
                v.getDescription(),
                String.valueOf(v.getDateDebut()),
                String.valueOf(v.getDateFin())
        );

        return calculateScore(texte, mots);
    }

    private int scorePublication(Publication v, List<String> mots) {

        String texte = join(
                v.getTitre(),
                v.getType(),
                String.valueOf(v.getAnnee()),
                v.getAuteurPrincipal(),
                v.getEquipe(),
                v.getDoi(),
                v.getLien(),
                v.getResume()
        );

        return calculateScore(texte, mots);
    }

    private int calculateScore(String texte, List<String> mots) {

        String normalizedText = normalize(texte);
        int score = 0;

        for (String mot : mots) {
            if (normalizedText.contains(mot)) {
                score++;
            }
        }

        return score;
    }

    private String join(String... values) {

        return Arrays.stream(values)
                .filter(Objects::nonNull)
                .filter(value -> !value.equals("null"))
                .collect(Collectors.joining(" "));
    }

    private String normalize(String value) {

        if (value == null) {
            return "";
        }

        String normalized = Normalizer.normalize(
                value.toLowerCase(Locale.ROOT),
                Normalizer.Form.NFD
        );

        return normalized
                .replaceAll("\\p{M}", "")
                .replaceAll("[^a-z0-9@._\\- ]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }
}
