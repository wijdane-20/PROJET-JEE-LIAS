package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.RoleHistorique;
import ma.fsbenmsik.lias.repository.RoleHistoriqueRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoleHistoriqueService {
    private final RoleHistoriqueRepository repository;

    public RoleHistoriqueService(RoleHistoriqueRepository repository) {
        this.repository = repository;
    }

    public List<RoleHistorique> getAll() {
        return repository.findAll();
    }

    public RoleHistorique save(RoleHistorique value) {
        return repository.save(value);
    }

    public RoleHistorique update(Long id, RoleHistorique value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
