package ma.fsbenmsik.lias.config;

import ma.fsbenmsik.lias.service.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;

    public SecurityConfig(CustomUserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration
    ) throws Exception {
        return configuration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> {})

                .authorizeHttpRequests(auth -> auth

                        // CORS
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                        // Endpoints publics
                        .requestMatchers("/api/auth/**", "/api/public/**").permitAll()

                        // Consultation publique
                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/equipes/**",
                                "/api/publications/**",
                                "/api/evenements/**"
                        ).permitAll()

                        // Demande d'adhésion publique
                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/demandes-adhesion"
                        ).permitAll()

                        // Gestion des demandes :
                        // directeur actif ou administrateur
                        .requestMatchers("/api/demandes-adhesion/**")
                        .hasAnyAuthority(
                                "ROLE_ADMIN",
                                "MANDAT_DIRECTEUR"
                        )

                        // Administration technique
                        .requestMatchers("/api/audit/**")
                        .hasAuthority("ROLE_ADMIN")

                        // Gouvernance
                        .requestMatchers(
                                "/api/mandats/**",
                                "/api/roles-historiques/**",
                                "/api/affiliations/**"
                        )
                        .hasAnyAuthority(
                                "ROLE_ADMIN",
                                "MANDAT_DIRECTEUR"
                        )

                        // Rapport annuel
                        .requestMatchers("/api/rapport/**")
                        .hasAnyAuthority(
                                "ROLE_ADMIN",
                                "MANDAT_DIRECTEUR",
                                "MANDAT_VICE_DIRECTEUR"
                        )

                        // Modules internes
                        .requestMatchers(
                                "/api/documents/**",
                                "/api/materiels/**",
                                "/api/besoins-materiel/**",
                                "/api/discussions/**",
                                "/api/reunions-pv/**",
                                "/api/conventions/**",
                                "/api/notifications/**"
                        )
                        .hasAnyAuthority(
                                "ROLE_ADMIN",
                                "STATUT_PERMANENT",
                                "MANDAT_DIRECTEUR",
                                "MANDAT_VICE_DIRECTEUR",
                                "MANDAT_CHEF_EQUIPE"
                        )

                        // Ajouter / modifier des publications
                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/publications/**"
                        )
                        .hasAnyAuthority(
                                "ROLE_ADMIN",
                                "STATUT_PERMANENT",
                                "STATUT_DOCTORANT",
                                "STATUT_ASSOCIE"
                        )

                        .requestMatchers(
                                HttpMethod.PUT,
                                "/api/publications/**"
                        )
                        .hasAnyAuthority(
                                "ROLE_ADMIN",
                                "STATUT_PERMANENT",
                                "STATUT_DOCTORANT",
                                "STATUT_ASSOCIE"
                        )

                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/api/publications/**"
                        )
                        .hasAnyAuthority(
                                "ROLE_ADMIN",
                                "STATUT_PERMANENT"
                        )

                        // Le reste nécessite au minimum une connexion
                        .requestMatchers("/api/**").authenticated()

                        .anyRequest().permitAll()
                )

                .userDetailsService(userDetailsService)
                .httpBasic(basic -> {});

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(
                List.of("http://localhost:4200")
        );

        configuration.setAllowedMethods(
                List.of(
                        "GET",
                        "POST",
                        "PUT",
                        "DELETE",
                        "OPTIONS"
                )
        );

        configuration.setAllowedHeaders(List.of("*"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration(
                "/**",
                configuration
        );

        return source;
    }
}