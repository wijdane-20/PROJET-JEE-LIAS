package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.BesoinMateriel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BesoinMaterielRepository extends JpaRepository<BesoinMateriel, Long> {
}
