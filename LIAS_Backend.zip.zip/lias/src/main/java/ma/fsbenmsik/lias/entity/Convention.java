package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "conventions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Convention {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String partenaire;
    private String titre;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    private String document;
    @Column(length = 3000)
    private String description;
    private boolean active;
}
