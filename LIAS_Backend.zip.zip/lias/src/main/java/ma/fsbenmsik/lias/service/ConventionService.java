package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.Convention;
import ma.fsbenmsik.lias.repository.ConventionRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ConventionService {
    private final ConventionRepository repository;

    public ConventionService(ConventionRepository repository) {
        this.repository = repository;
    }

    public List<Convention> getAll() {
        return repository.findAll();
    }

    public Convention save(Convention value) {
        return repository.save(value);
    }

    public Convention update(Long id, Convention value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
