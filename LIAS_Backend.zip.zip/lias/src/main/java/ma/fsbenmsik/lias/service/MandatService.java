package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.Mandat;
import ma.fsbenmsik.lias.repository.MandatRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MandatService {

    private final MandatRepository repository;

    public MandatService(MandatRepository repository) {
        this.repository = repository;
    }

    public List<Mandat> getAll() {
        return repository.findAll();
    }

    public List<Mandat> getByMembre(Long membreId) {
        return repository.findByMembreId(membreId);
    }

    public Mandat save(Mandat mandat) {
        return repository.save(mandat);
    }

    public Mandat update(Long id, Mandat mandat) {
        mandat.setId(id);
        return repository.save(mandat);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}