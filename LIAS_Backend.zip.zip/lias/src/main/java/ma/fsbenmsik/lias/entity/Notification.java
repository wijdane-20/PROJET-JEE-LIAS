package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String destinataire;
    private String type;
    @Column(length = 3000)
    private String message;
    private LocalDateTime dateCreation;
    private boolean lue;
}
