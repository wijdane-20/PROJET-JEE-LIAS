package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.DemandeAdhesion;
import ma.fsbenmsik.lias.service.DemandeAdhesionService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/demandes-adhesion")
@CrossOrigin(origins = "*")
public class DemandeAdhesionController {
    private final DemandeAdhesionService service;
    private final AuditService audit;

    public DemandeAdhesionController(DemandeAdhesionService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping
    public List<DemandeAdhesion> getAll() {
        return service.getAll();
    }

    @PostMapping
    public DemandeAdhesion create(@RequestBody DemandeAdhesion demande) {
        if (demande.getDateDemande() == null) demande.setDateDemande(LocalDateTime.now());
        if (demande.getStatut() == null || demande.getStatut().isBlank()) demande.setStatut("EN_ATTENTE");
        DemandeAdhesion saved = service.save(demande);
        audit.log("CREATE", "DemandeAdhesion", saved.getId(), demande.getEmail(), "Nouvelle demande d'adhésion");
        return saved;
    }

    @PutMapping("/{id}")
    public DemandeAdhesion update(@PathVariable Long id, @RequestBody DemandeAdhesion demande) {
        DemandeAdhesion saved = service.update(id, demande);
        audit.log("UPDATE", "DemandeAdhesion", id, "direction", "Décision / modification demande");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "DemandeAdhesion", id, "direction", "Suppression demande");
    }
}
