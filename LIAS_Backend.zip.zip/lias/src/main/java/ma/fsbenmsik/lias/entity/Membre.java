package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "membres")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Membre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    private String prenom;

    @Column(unique = true, nullable = false)
    private String email;

    private String statut;

    private String etablissementOrigine;

    private String laboratoireOrigine;

    @Column(length = 2000)
    private String biographie;

    private String centresInteret;

    private LocalDate dateNaissance;

    private LocalDate dateEmbauche;

    private LocalDate dateAffiliation;

    private String photo;

    private boolean actif = true;
}