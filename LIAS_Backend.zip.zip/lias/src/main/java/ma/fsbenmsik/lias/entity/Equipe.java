package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "equipes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Equipe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    private String description;

    private String domaineRecherche;

    private boolean active;
}