package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.repository.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/rapport")
@CrossOrigin(origins = "*")
public class RapportAnnuelController {
    private final MembreRepository membres;
    private final EquipeRepository equipes;
    private final PublicationRepository publications;
    private final EvenementRepository evenements;
    private final DocumentRepository documents;

    public RapportAnnuelController(MembreRepository membres, EquipeRepository equipes,
                                   PublicationRepository publications, EvenementRepository evenements,
                                   DocumentRepository documents) {
        this.membres = membres;
        this.equipes = equipes;
        this.publications = publications;
        this.evenements = evenements;
        this.documents = documents;
    }

    @GetMapping("/{annee}")
    public Map<String, Object> rapport(@PathVariable int annee) {
        long publicationsAnnee = publications.findAll().stream()
                .filter(p -> p.getAnnee() != null && p.getAnnee() == annee)
                .count();

        long evenementsAnnee = evenements.findAll().stream()
                .filter(e -> e.getDateDebut() != null && e.getDateDebut().getYear() == annee)
                .count();

        return Map.of(
                "annee", annee,
                "membres", membres.count(),
                "equipes", equipes.count(),
                "publications", publicationsAnnee,
                "evenements", evenementsAnnee,
                "documents", documents.count()
        );
    }
}
