package ma.fsbenmsik.lias.config;

import ma.fsbenmsik.lias.entity.Equipe;
import ma.fsbenmsik.lias.entity.Membre;
import ma.fsbenmsik.lias.entity.Role;
import ma.fsbenmsik.lias.entity.Utilisateur;
import ma.fsbenmsik.lias.repository.EquipeRepository;
import ma.fsbenmsik.lias.repository.MembreRepository;
import ma.fsbenmsik.lias.repository.UtilisateurRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UtilisateurRepository utilisateurRepository;
    private final MembreRepository membreRepository;
    private final EquipeRepository equipeRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(
            UtilisateurRepository utilisateurRepository,
            MembreRepository membreRepository,
            EquipeRepository equipeRepository,
            PasswordEncoder passwordEncoder) {

        this.utilisateurRepository = utilisateurRepository;
        this.membreRepository = membreRepository;
        this.equipeRepository = equipeRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {

        initialiserAdminPrincipal();
        desactiverAncienAdmin();
        initialiserMembres();
        initialiserCompteDoctorantAhlam();
        initialiserEquipes();
    }

    private void initialiserAdminPrincipal() {

        String adminEmail = "wijdanebenkhadir03@gmail.com";
        String adminPassword = "wijdane20";

        Utilisateur admin = utilisateurRepository.findByEmail(adminEmail)
                .orElseGet(() -> Utilisateur.builder()
                        .nom("Wijdane Benkhadir")
                        .email(adminEmail)
                        .build());

        admin.setNom("Wijdane Benkhadir");
        admin.setEmail(adminEmail);
        admin.setPassword(passwordEncoder.encode(adminPassword));
        admin.setRole(Role.ADMIN);
        admin.setActif(true);

        utilisateurRepository.save(admin);
    }

    private void desactiverAncienAdmin() {

        utilisateurRepository.findByEmail("admin@lias.ma")
                .ifPresent(ancienAdmin -> {
                    ancienAdmin.setActif(false);
                    utilisateurRepository.save(ancienAdmin);
                });
    }

    private void initialiserCompteDoctorantAhlam() {

        String email = "ahlam@lias.ma";
        String password = "Ahlam123";

        Utilisateur utilisateur = utilisateurRepository.findByEmail(email)
                .orElseGet(() -> Utilisateur.builder()
                        .nom("Ahlam Benkhadir")
                        .email(email)
                        .build());

        utilisateur.setNom("Ahlam Benkhadir");
        utilisateur.setEmail(email);
        utilisateur.setPassword(passwordEncoder.encode(password));
        utilisateur.setRole(Role.MEMBRE);
        utilisateur.setActif(true);

        utilisateurRepository.save(utilisateur);
    }

    private void initialiserMembres() {

        ajouterMembreSiAbsent(
                "Ahlam",
                "Benkhadir",
                "ahlam@lias.ma",
                "DOCTORANT",
                "Université Hassan II",
                "LIAS",
                "Compte doctorant de démonstration pour la plateforme LIAS.",
                "Data Science, Intelligence Artificielle",
                null,
                null,
                LocalDate.of(2026, 10, 1)
        );

        ajouterMembreSiAbsent(
                "Karim",
                "El Amrani",
                "karim.elamrani@lias.ma",
                "PERMANENT",
                "Université Hassan II",
                "LIAS",
                "Enseignant-chercheur spécialisé en intelligence artificielle et systèmes intelligents.",
                "Intelligence artificielle, Machine Learning, Vision",
                LocalDate.of(1984, 4, 18),
                LocalDate.of(2012, 9, 1),
                LocalDate.of(2013, 1, 15)
        );

        ajouterMembreSiAbsent(
                "Salma",
                "Bennani",
                "salma.bennani@lias.ma",
                "PERMANENT",
                "Université Hassan II",
                "LIAS",
                "Chercheuse en science des données, systèmes distribués et analyse intelligente.",
                "Data Science, Big Data, Cloud",
                LocalDate.of(1987, 8, 12),
                LocalDate.of(2015, 9, 1),
                LocalDate.of(2016, 2, 10)
        );

        ajouterMembreSiAbsent(
                "Yassine",
                "Lahlou",
                "yassine.lahlou@lias.ma",
                "ASSOCIE",
                "Université Mohammed V",
                "Laboratoire Informatique & Télécoms",
                "Chercheur associé travaillant sur la cybersécurité et les réseaux intelligents.",
                "Cybersécurité, Réseaux, IoT",
                LocalDate.of(1982, 11, 2),
                LocalDate.of(2010, 9, 1),
                LocalDate.of(2020, 1, 20)
        );

        ajouterMembreSiAbsent(
                "Imane",
                "El Fassi",
                "imane.elfassi@lias.ma",
                "DOCTORANT",
                "Université Hassan II",
                "LIAS",
                "Doctorante travaillant sur l'intelligence artificielle appliquée au diagnostic médical.",
                "Deep Learning, Imagerie médicale, IA",
                LocalDate.of(1998, 6, 22),
                LocalDate.of(2023, 10, 1),
                LocalDate.of(2023, 10, 1)
        );

        ajouterMembreSiAbsent(
                "Omar",
                "Berrada",
                "omar.berrada@lias.ma",
                "DOCTORANT",
                "Université Hassan II",
                "LIAS",
                "Doctorant spécialisé dans la détection d'anomalies et la sécurité des objets connectés.",
                "IoT, Anomaly Detection, Edge Computing",
                LocalDate.of(1997, 2, 14),
                LocalDate.of(2022, 10, 1),
                LocalDate.of(2022, 10, 1)
        );
    }

    private void ajouterMembreSiAbsent(
            String prenom,
            String nom,
            String email,
            String statut,
            String etablissementOrigine,
            String laboratoireOrigine,
            String biographie,
            String centresInteret,
            LocalDate dateNaissance,
            LocalDate dateEmbauche,
            LocalDate dateAffiliation) {

        boolean existe = membreRepository.findAll()
                .stream()
                .anyMatch(membre ->
                        membre.getEmail() != null &&
                                membre.getEmail().equalsIgnoreCase(email)
                );

        if (!existe) {

            Membre membre = Membre.builder()
                    .prenom(prenom)
                    .nom(nom)
                    .email(email)
                    .statut(statut)
                    .etablissementOrigine(etablissementOrigine)
                    .laboratoireOrigine(laboratoireOrigine)
                    .biographie(biographie)
                    .centresInteret(centresInteret)
                    .dateNaissance(dateNaissance)
                    .dateEmbauche(dateEmbauche)
                    .dateAffiliation(dateAffiliation)
                    .photo("")
                    .actif(true)
                    .build();

            membreRepository.save(membre);
        }
    }

    private void initialiserEquipes() {

        ajouterEquipeSiAbsente(
                "Intelligence Artificielle & Vision",
                "Intelligence artificielle, vision par ordinateur et apprentissage profond",
                "Développement de méthodes d'IA pour l'analyse d'images, la vision par ordinateur et les applications intelligentes."
        );

        ajouterEquipeSiAbsente(
                "Data Science & Systèmes Distribués",
                "Big Data, Data Science, Cloud Computing",
                "Analyse de données massives, systèmes distribués, cloud et plateformes intelligentes pour la recherche scientifique."
        );

        ajouterEquipeSiAbsente(
                "Cybersécurité & Réseaux",
                "Cybersécurité, réseaux et IoT",
                "Sécurité des systèmes, détection d'intrusions, réseaux intelligents et protection des infrastructures connectées."
        );

        ajouterEquipeSiAbsente(
                "Systèmes Intelligents & IoT",
                "IoT, systèmes embarqués et Edge Computing",
                "Conception de systèmes connectés, embarqués et intelligents avec traitement local et optimisation des ressources."
        );
    }

    private void ajouterEquipeSiAbsente(
            String nom,
            String domaineRecherche,
            String description) {

        boolean existe = equipeRepository.findAll()
                .stream()
                .anyMatch(equipe ->
                        equipe.getNom() != null &&
                                equipe.getNom().equalsIgnoreCase(nom)
                );

        if (!existe) {

            Equipe equipe = Equipe.builder()
                    .nom(nom)
                    .domaineRecherche(domaineRecherche)
                    .description(description)
                    .active(true)
                    .build();

            equipeRepository.save(equipe);
        }
    }
}