package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.Convention;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConventionRepository extends JpaRepository<Convention, Long> {
}
