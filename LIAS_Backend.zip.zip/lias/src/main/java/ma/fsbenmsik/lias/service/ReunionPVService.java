package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.ReunionPV;
import ma.fsbenmsik.lias.repository.ReunionPVRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ReunionPVService {
    private final ReunionPVRepository repository;

    public ReunionPVService(ReunionPVRepository repository) {
        this.repository = repository;
    }

    public List<ReunionPV> getAll() {
        return repository.findAll();
    }

    public ReunionPV save(ReunionPV value) {
        return repository.save(value);
    }

    public ReunionPV update(Long id, ReunionPV value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
