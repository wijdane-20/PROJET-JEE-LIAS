package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Evenement;
import ma.fsbenmsik.lias.service.EvenementService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/evenements")
@CrossOrigin(origins = "*")
public class EvenementController {

    private final EvenementService evenementService;

    public EvenementController(EvenementService evenementService) {
        this.evenementService = evenementService;
    }

    @GetMapping
    public List<Evenement> getAllEvenements() {
        return evenementService.getAllEvenements();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Evenement> getEvenementById(
            @PathVariable Long id) {

        return evenementService
                .getEvenementById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Evenement createEvenement(
            @RequestBody Evenement evenement) {

        return evenementService.saveEvenement(evenement);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Evenement> updateEvenement(
            @PathVariable Long id,
            @RequestBody Evenement evenement) {

        return evenementService
                .getEvenementById(id)
                .map(existing -> {
                    evenement.setId(id);
                    return ResponseEntity.ok(
                            evenementService.saveEvenement(evenement)
                    );
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEvenement(
            @PathVariable Long id) {

        if (evenementService.getEvenementById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        evenementService.deleteEvenement(id);

        return ResponseEntity.noContent().build();
    }
}