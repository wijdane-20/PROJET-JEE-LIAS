package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Discussion;
import ma.fsbenmsik.lias.service.DiscussionService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/discussions")
@CrossOrigin(origins = "*")
public class DiscussionController {
    private final DiscussionService service;
    private final AuditService audit;

    public DiscussionController(DiscussionService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<Discussion> getAll() { return service.getAll(); }

    @PostMapping
    public Discussion create(@RequestBody Discussion value) {
        if (value.getDateCreation() == null) value.setDateCreation(LocalDateTime.now());
        Discussion saved = service.save(value);
        audit.log("CREATE", "Discussion", saved.getId(), "utilisateur", "Création Discussion");
        return saved;
    }

    @PutMapping("/{id}")
    public Discussion update(@PathVariable Long id, @RequestBody Discussion value) {
        Discussion saved = service.update(id, value);
        audit.log("UPDATE", "Discussion", id, "utilisateur", "Modification Discussion");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "Discussion", id, "utilisateur", "Suppression Discussion");
    }
}
