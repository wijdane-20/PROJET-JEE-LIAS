package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.Affiliation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AffiliationRepository
        extends JpaRepository<Affiliation, Long> {

    List<Affiliation> findByMembreId(Long membreId);
}