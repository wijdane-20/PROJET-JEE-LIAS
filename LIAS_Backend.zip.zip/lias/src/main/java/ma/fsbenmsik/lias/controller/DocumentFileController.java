package ma.fsbenmsik.lias.controller;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin(origins = "http://localhost:4200")
public class DocumentFileController {

    private final Path uploadDir = Paths.get("uploads");

    public DocumentFileController() throws IOException {
        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }
    }

    @PostMapping("/upload")
    public ResponseEntity<String> upload(@RequestParam("file") MultipartFile file) throws IOException {

        String originalName = file.getOriginalFilename();

        if (originalName == null || originalName.isBlank()) {
            return ResponseEntity.badRequest().body("{\"error\":\"Nom de fichier invalide\"}");
        }

        String safeName = originalName.replaceAll("[^a-zA-Z0-9._-]", "_");

        Path destination = uploadDir.resolve(safeName);

        Files.copy(
                file.getInputStream(),
                destination,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING
        );

        return ResponseEntity.ok(
                "{\"filename\":\"" + safeName + "\"}"
        );
    }

    @GetMapping("/download/{filename}")
    public ResponseEntity<Resource> download(
            @PathVariable String filename
    ) throws IOException {

        Path filePath = uploadDir.resolve(filename).normalize();

        Resource resource = new UrlResource(filePath.toUri());

        if (!resource.exists()) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + resource.getFilename() + "\""
                )
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }
}