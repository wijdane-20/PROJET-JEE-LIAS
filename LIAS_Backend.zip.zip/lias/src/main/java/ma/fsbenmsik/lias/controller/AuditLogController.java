package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.AuditLog;
import ma.fsbenmsik.lias.service.AuditLogService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/audit")
@CrossOrigin(origins = "*")
public class AuditLogController {
    private final AuditLogService service;

    public AuditLogController(AuditLogService service) {
        this.service = service;
    }

    @GetMapping public List<AuditLog> getAll() { return service.getAll(); }
    @PostMapping public AuditLog create(@RequestBody AuditLog value) { return service.save(value); }
    @PutMapping("/{id}") public AuditLog update(@PathVariable Long id, @RequestBody AuditLog value) { return service.update(id, value); }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { service.delete(id); }
}
