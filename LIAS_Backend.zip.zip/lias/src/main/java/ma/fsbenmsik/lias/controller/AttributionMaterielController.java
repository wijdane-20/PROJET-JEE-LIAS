package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.AttributionMateriel;
import ma.fsbenmsik.lias.service.AttributionMaterielService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/attributions-materiel")
@CrossOrigin(origins = "*")
public class AttributionMaterielController {
    private final AttributionMaterielService service;
    private final AuditService audit;

    public AttributionMaterielController(AttributionMaterielService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<AttributionMateriel> getAll() { return service.getAll(); }

    @PostMapping
    public AttributionMateriel create(@RequestBody AttributionMateriel value) {

        AttributionMateriel saved = service.save(value);
        audit.log("CREATE", "AttributionMateriel", saved.getId(), "utilisateur", "Création AttributionMateriel");
        return saved;
    }

    @PutMapping("/{id}")
    public AttributionMateriel update(@PathVariable Long id, @RequestBody AttributionMateriel value) {
        AttributionMateriel saved = service.update(id, value);
        audit.log("UPDATE", "AttributionMateriel", id, "utilisateur", "Modification AttributionMateriel");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "AttributionMateriel", id, "utilisateur", "Suppression AttributionMateriel");
    }
}
