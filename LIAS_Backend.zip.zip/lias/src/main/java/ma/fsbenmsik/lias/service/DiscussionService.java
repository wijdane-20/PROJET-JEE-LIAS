package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.Discussion;
import ma.fsbenmsik.lias.repository.DiscussionRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DiscussionService {
    private final DiscussionRepository repository;

    public DiscussionService(DiscussionRepository repository) {
        this.repository = repository;
    }

    public List<Discussion> getAll() {
        return repository.findAll();
    }

    public Discussion save(Discussion value) {
        return repository.save(value);
    }

    public Discussion update(Long id, Discussion value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
