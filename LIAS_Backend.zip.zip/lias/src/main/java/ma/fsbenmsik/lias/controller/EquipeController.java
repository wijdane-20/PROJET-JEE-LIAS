package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Equipe;
import ma.fsbenmsik.lias.service.EquipeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/equipes")
@CrossOrigin(origins = "*")
public class EquipeController {

    private final EquipeService equipeService;

    public EquipeController(EquipeService equipeService) {
        this.equipeService = equipeService;
    }

    @GetMapping
    public List<Equipe> getAllEquipes() {
        return equipeService.getAllEquipes();
    }

    @PostMapping
    public Equipe createEquipe(@RequestBody Equipe equipe) {
        return equipeService.saveEquipe(equipe);
    }

    @PutMapping("/{id}")
    public Equipe updateEquipe(
            @PathVariable Long id,
            @RequestBody Equipe equipe) {

        equipe.setId(id);
        return equipeService.saveEquipe(equipe);
    }

    @DeleteMapping("/{id}")
    public void deleteEquipe(@PathVariable Long id) {
        equipeService.deleteEquipe(id);
    }
}