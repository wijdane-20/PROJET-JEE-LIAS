package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "evenements")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Evenement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titre;

    private String type;

    private LocalDate dateDebut;

    private LocalDate dateFin;

    private String lieu;

    @Column(length = 2000)
    private String description;

    private String organisateur;

    private boolean archive = false;
}