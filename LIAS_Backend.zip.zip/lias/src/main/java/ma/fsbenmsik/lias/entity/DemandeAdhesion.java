package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "demandes_adhesion")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class DemandeAdhesion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nom;
    private String prenom;
    private String email;
    private String cvFichier;
    @Column(length = 4000)
    private String motivation;
    private String statut;
    private String commentaireDecision;
    private LocalDateTime dateDemande;
}
