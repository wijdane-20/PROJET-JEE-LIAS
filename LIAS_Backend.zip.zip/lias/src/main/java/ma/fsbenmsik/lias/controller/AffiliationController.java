package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.Affiliation;
import ma.fsbenmsik.lias.service.AffiliationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/affiliations")
@CrossOrigin(origins = "*")
public class AffiliationController {

    private final AffiliationService service;

    public AffiliationController(AffiliationService service) {
        this.service = service;
    }

    @GetMapping
    public List<Affiliation> getAll() {
        return service.getAll();
    }

    @GetMapping("/membre/{membreId}")
    public List<Affiliation> getByMembre(
            @PathVariable Long membreId) {

        return service.getByMembre(membreId);
    }

    @PostMapping
    public Affiliation create(
            @RequestBody Affiliation affiliation) {

        return service.save(affiliation);
    }

    @PutMapping("/{id}")
    public Affiliation update(
            @PathVariable Long id,
            @RequestBody Affiliation affiliation) {

        return service.update(id, affiliation);
    }

    @DeleteMapping("/{id}")
    public void delete(
            @PathVariable Long id) {

        service.delete(id);
    }
}