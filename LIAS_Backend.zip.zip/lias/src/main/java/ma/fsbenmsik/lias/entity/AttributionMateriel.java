package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "attributions_materiel")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AttributionMateriel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long materielId;
    private Long membreId;
    private Integer quantite;
    private LocalDate dateAttribution;
    private boolean rendu;
}
