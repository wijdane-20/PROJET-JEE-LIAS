package ma.fsbenmsik.lias.repository;

import ma.fsbenmsik.lias.entity.RoleHistorique;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleHistoriqueRepository extends JpaRepository<RoleHistorique, Long> {
}
