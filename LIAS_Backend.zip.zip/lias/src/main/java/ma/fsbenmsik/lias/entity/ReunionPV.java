package ma.fsbenmsik.lias.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "reunions_pv")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ReunionPV {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titre;
    private LocalDate dateReunion;
    @Column(length = 4000)
    private String ordreDuJour;
    private String cheminPv;
    private boolean archive;
}
