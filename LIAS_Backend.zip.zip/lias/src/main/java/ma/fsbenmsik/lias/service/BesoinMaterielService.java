package ma.fsbenmsik.lias.service;

import ma.fsbenmsik.lias.entity.BesoinMateriel;
import ma.fsbenmsik.lias.repository.BesoinMaterielRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BesoinMaterielService {
    private final BesoinMaterielRepository repository;

    public BesoinMaterielService(BesoinMaterielRepository repository) {
        this.repository = repository;
    }

    public List<BesoinMateriel> getAll() {
        return repository.findAll();
    }

    public BesoinMateriel save(BesoinMateriel value) {
        return repository.save(value);
    }

    public BesoinMateriel update(Long id, BesoinMateriel value) {
        value.setId(id);
        return repository.save(value);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
