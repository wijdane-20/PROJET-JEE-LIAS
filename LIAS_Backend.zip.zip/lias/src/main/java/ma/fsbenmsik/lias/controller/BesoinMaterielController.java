package ma.fsbenmsik.lias.controller;

import ma.fsbenmsik.lias.entity.BesoinMateriel;
import ma.fsbenmsik.lias.service.BesoinMaterielService;
import ma.fsbenmsik.lias.service.AuditService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/besoins-materiel")
@CrossOrigin(origins = "*")
public class BesoinMaterielController {
    private final BesoinMaterielService service;
    private final AuditService audit;

    public BesoinMaterielController(BesoinMaterielService service, AuditService audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping public List<BesoinMateriel> getAll() { return service.getAll(); }

    @PostMapping
    public BesoinMateriel create(@RequestBody BesoinMateriel value) {
        if (value.getDateDemande() == null) value.setDateDemande(LocalDateTime.now()); if (value.getStatut() == null || value.getStatut().isBlank()) value.setStatut("EN_ATTENTE");
        BesoinMateriel saved = service.save(value);
        audit.log("CREATE", "BesoinMateriel", saved.getId(), "utilisateur", "Création BesoinMateriel");
        return saved;
    }

    @PutMapping("/{id}")
    public BesoinMateriel update(@PathVariable Long id, @RequestBody BesoinMateriel value) {
        BesoinMateriel saved = service.update(id, value);
        audit.log("UPDATE", "BesoinMateriel", id, "utilisateur", "Modification BesoinMateriel");
        return saved;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
        audit.log("DELETE", "BesoinMateriel", id, "utilisateur", "Suppression BesoinMateriel");
    }
}
